<?php 

include ('../php/conexion.php');
$link=conectar();

$id=$_POST['id'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$direccion=$_POST['direccion'];
$telefono=$_POST['telefono'];
$fecha=$_POST['fecha'];
$fecha_salida=$_POST['fecha_salida'];
$coment=$_POST['coment'];
$coment_after=$_POST['coment_after'];


$sql="UPDATE tecnicos SET nombre='$nombre',apellido='$apellido',fec_contrato='$fecha',fec_salida='$fecha_salida',direccion='$direccion',telefono='$telefono',comentarios='$coment', comentarios_after='$coment_after' where id_tecnico='$id';";


if(mysql_query($sql,$link)){
	header('Location: hecho_edit.php');
}
else{
	header('location: edit_error.php');
}


 ?>