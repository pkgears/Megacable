<?php
	session_start();
	include ("../php/sesion.php");
 ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Editar técnico</title>
	<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
	<div class="" id="contenido">
		<header>
			<img src="../logo.png" alt="Megacable" width="150px" height="150px">
			<h1 class="titulo">Editar técnico</h1>
			<a href="../inicio.php">Regresar a inicio</a>
		</header>
		<nav>
			<ul class="nav">
				<li><a href="../inventarios/menu_inventarios.php">Inventario <div class="flecha"></div></a>
					<ul>
						<li><a href="../inventarios/inventario_acutal.php">Inventario actual</a></li>
						<li><a href="../inventarios/inventarios_anteriores.php">Inventarios anteriores</a></li>
						<li><a href="../inventarios/nuevo_inventario.php">Nuevo inventario</a></li>
					</ul>
				</li>
				<li><a href="../equipos/menu_equipos.php">Equipos <div class="flecha"></div></a>
					<ul>
						<li><a href="../equipos/lista_equipos.php">Lista de equipos</a></li>
						<li><a href="../equipos/agregar_equipos.php">Agregar nuevos equipos</a></li>
					</ul>
				</li>
				<li><a href="../bitacoras/menu_bitacoras.php">Bitacora <div class="flecha"></div></a>
					<ul>
						<li><a href="../bitacoras/nueva_bitacora.php">Nueva bitacora </a></li>
						<li><a href="../bitacoras/consulta_bitacora.php">Consulta de bitacoras</a></li>
					</ul>
				</li>
				<li><a href="../tecnicos/menu_tecnicos.php">Tecnicos <div class="flecha"></div></a>
					<ul>
						<li><a href="../tecnicos/lista_tecnicos.php">Lista de técnicos</a></li>
						<li><a href="../tecnicos/agregar_tecnico.php">Agregar técnico</a></li>
					</ul>
				</li>
			</ul>
			<h3 class="user">Has iniciado sesion como <span class="user nombre"><a href="../usuario.php"><?php echo $_SESSION["usuario"];?></a></span>
			<span class="salir"><a href="../php/logout.php">(cerrar sesión)</a></span></h3>
		</nav>
		<section id="central">
			<div class="add_tecnico">
				<form action="edit_tecnico.php" method="POST">
					<table>
						<?php
						include ('../php/conexion.php');
						$link=conectar();
						$tecnico=$_GET['tecnico'];
						$sql="SELECT * from tecnicos where id_tecnico='$tecnico';";
						$resultado=mysql_query($sql,$link);
						$row=mysql_fetch_array($resultado);
						 echo  "<input type='hidden' name='id' value=".$row['id_tecnico'].">
						 		<tr><td>Nombre:</td><td><input type='text' name='nombre' value=".$row['nombre']."></td></tr>
								<tr><td>Apellido:</td><td><input type='text' name='apellido' value=".$row['apellido']."></td></tr>
								<tr><td>Direccion:</td><td><textarea name='direccion' id='' cols='30' rows='5'>".$row['direccion']."</textarea></td></tr>
								<tr><td>Teléfono:</td><td><input type='tel' pattern='[0-9]+' name='telefono' value=".$row['telefono']." title='Este campo unicamente acepta numeros'></td></tr>
								<tr><td>Fecha de contrato:</td><td><input type='date' name='fecha' value=".$row['fec_contrato']."></td></tr>
								<tr><td>Fecha de salida:</td><td><input type='date' name='fecha_salida' value=".$row['fec_salida']."></td></tr>
								<tr><td>Comentarios de contratación:</td><td><textarea name='coment' id='' cols='30' rows='5'>".$row['comentarios']."</textarea></td></tr>
								<tr><td>Comentarios de salida:</td><td><textarea name='coment_after' id='' cols='30' rows='5'>".$row['comentarios_after']."</textarea></td></tr>";

						?>
					</table><br>
					<input type="submit" value="Guardar" class="boton">
				</form>
			</div>
		</section>
		<footer>
			<p id="version">Version 1.0 Ultima actualización 00/00/00</p>
			<p class="" id="powered">Powered by César Eduardo</p>
		</footer>
	</div>
</body>
</html>