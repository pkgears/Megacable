<?php
	session_start();
	include ("../php/sesion.php");
 ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Agregar técnico</title>
	<link rel="stylesheet" href="../css/estilos.css">
	<script src="../js/jquery_1.4.js" type="text/javascript"></script>
	<script src="../js/jquery.validate.js" type="text/javascript"></script>
</head>
<body>
	<div class="" id="contenido">
		<header>
			<img src="../logo.png" alt="Megacable" width="150px" height="150px">
			<h1 class="titulo">Agregar técnico</h1>
			<a href="../inicio.php">Regresar a inicio</a>
		</header>
		<nav>
			<ul class="nav">
				<li><a href="../inventarios/menu_inventarios.php">Inventario <div class="flecha"></div></a>
					<ul>
						<li><a href="../inventarios/inventario_acutal.php">Inventario actual</a></li>
						<li><a href="../inventarios/inventarios_anteriores.php">Inventarios anteriores</a></li>
						<li><a href="../inventarios/nuevo_inventario.php">Nuevo inventario</a></li>
					</ul>
				</li>
				<li><a href="../equipos/menu_equipos.php">Equipos <div class="flecha"></div></a>
					<ul>
						<li><a href="../equipos/lista_equipos.php">Lista de equipos</a></li>
						<li><a href="../equipos/agregar_equipos.php">Agregar nuevos equipos</a></li>
					</ul>
				</li>
				<li><a href="../bitacoras/menu_bitacoras.php">Bitacora <div class="flecha"></div></a>
					<ul>
						<li><a href="../bitacoras/nueva_bitacora.php">Nueva bitacora </a></li>
						<li><a href="../bitacoras/consulta_bitacora.php">Consulta de bitacoras</a></li>
					</ul>
				</li>
				<li><a href="../tecnicos/menu_tecnicos.php">Tecnicos <div class="flecha"></div></a>
					<ul>
						<li><a href="../tecnicos/lista_tecnicos.php">Lista de técnicos</a></li>
						<li><a href="../tecnicos/agregar_tecnico.php">Agregar técnico</a></li>
					</ul>
				</li>
			</ul>
			<h3 class="user">Has iniciado sesion como <span class="user nombre"><a href="../usuario.php"><?php echo $_SESSION["usuario"];?></a></span>
			<span class="salir"><a href="../php/logout.php">(cerrar sesión)</a></span></h3>
		</nav>
		<section id="central">
			<div class="add_tecnico">
				<form action="add_tecnico.php" method="POST" id="registro">
					<table>
						<tr><td>Nombre*:</td><td><input type="text" name='nombre' id="nombre" required></td></tr>
						<tr><td>Apellido*:</td><td><input type="text" name='apellido' id="apellido" required></td></tr>
						<tr><td>Direccion*:</td><td><textarea name="direccion" id="" cols="30" rows="5" id="direcion" required></textarea></td></tr>
						<tr><td>Teléfono*:</td><td><input type="text" name="telefono" id="telefono" required pattern="[0-9]+" title='Este campo unicamente acepta números'></td></tr>
						<tr><td>Fecha de contrato*:</td><td><input type="date" name="fecha" id="fecha" required></td></tr>
						<tr><td>Comentarios:</td><td><textarea name="coment" id="" cols="30" rows="5" id=""></textarea></td></tr>
					</table>
					<input type="submit" value="Guardar" class="boton">
				</form><br />
				<span id='obligatorio'>Los campos que esten marcados con '*' son obligatorios</span>
			</div>
		</section>
		<footer>
			<p id="version">Version 1.0 Ultima actualización 00/00/00</p>
			<p class="" id="powered">Powered by César Eduardo</p>
		</footer>
	</div>
</body>
</html>