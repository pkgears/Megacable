<?php 

include ('../php/conexion.php');
$link=conectar();

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$direccion=$_POST['direccion'];
$telefono=$_POST['telefono'];
$fecha=$_POST['fecha'];
$coment=$_POST['coment'];
$foto = $_FILES['imagen']['name'];


$sql="INSERT INTO `tecnicos`(`nombre`, `apellido`, `fec_contrato`, `direccion`, `telefono`, `comentarios`) VALUES ('$nombre','$apellido','$fecha','$direccion','$telefono','$coment');";

if(mysql_query($sql,$link)){
	header('Location: hecho.php');
}
else{
	header('location: add_error.php');
}


 ?>