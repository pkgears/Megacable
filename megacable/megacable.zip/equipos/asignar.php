<?php 

include ('../php/conexion.php');
$link=conectar();

$tecnico=$_POST['tecnico'];
$serie=$_POST["serie"];

$nuevo="UPDATE equipos SET id_tecnico='$tecnico' where no_serie='$serie';";
mysql_query($nuevo,$link);

if(mysql_query($nuevo,$link)){
	header("location:lista_equipos.php");

}
else{
	echo "<h1>No se pudo actualizar el registro</h1>";
 
}
?>
