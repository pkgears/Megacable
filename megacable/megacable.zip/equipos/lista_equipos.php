<?php
	session_start();
	include ("../php/sesion.php");
 ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Lista de equipos</title>
	<link rel="stylesheet" href="../css/estilos.css">

	<script language="JavaScript">
		function ocultar_mostrar(div){
			div = document.getElementById(div);
			//Verificamos si la capa esta oculta o no y como resultado
			//indicamos que cambie su valor distinto al actual. "none" o "block"
			div.style.display!='none'?
			div.style.display='none':div.style.display='block';
			}
	</script>
</head>
<body>
	<div class="" id="contenido">
		<header>
			<img src="../logo.png" alt="Megacable" width="150px" height="150px">
			<h1 class="titulo">Lista de equipos</h1>
			<a href="../inicio.php">Regresar a inicio</a>
		</header>
		<nav>
			<ul class="nav">
				<li><a href="../inventarios/menu_inventarios.php">Inventario <div class="flecha"></div></a>
					<ul>
						<li><a href="../inventarios/inventario_acutal.php">Inventario actual</a></li>
						<li><a href="../inventarios/inventarios_anteriores.php">Inventarios anteriores</a></li>
						<li><a href="../inventarios/nuevo_inventario.php">Nuevo inventario</a></li>
					</ul>
				</li>
				<li><a href="../equipos/menu_equipos.php">Equipos <div class="flecha"></div></a>
					<ul>
						<li><a href="../equipos/lista_equipos.php">Lista de equipos</a></li>
						<li><a href="../equipos/agregar_equipos.php">Agregar nuevos equipos</a></li>
					</ul>
				</li>
				<li><a href="../bitacoras/menu_bitacoras.php">Bitacora <div class="flecha"></div></a>
					<ul>
						<li><a href="../bitacoras/nueva_bitacora.php">Nueva bitacora </a></li>
						<li><a href="../bitacoras/consulta_bitacora.php">Consulta de bitacoras</a></li>
					</ul>
				</li>
				<li><a href="../tecnicos/menu_tecnicos.php">Tecnicos <div class="flecha"></div></a>
					<ul>
						<li><a href="../tecnicos/lista_tecnicos.php">Lista de técnicos</a></li>
						<li><a href="../tecnicos/agregar_tecnico.php">Agregar técnico</a></li>
					</ul>
				</li>
			</ul>
			<h3 class="user">Has iniciado sesion como <span class="user nombre"><a href="../usuario.php"><?php echo $_SESSION["usuario"];?></a></span>
			<span class="salir"><a href="../php/logout.php">(cerrar sesión)</a></span></h3>
		</nav>
		<section id="central">
			
			<div class="tabla" id="lista_equipos">
				<table>
					<?php
					include ("../php/conexion.php");
					$vuelta=0;
					$link=conectar();
					$sql="SELECT * FROM `equipos` LEFT JOIN `tecnicos` on tecnicos.id_tecnico= equipos.id_tecnico where no_serie>0 order by equipos.id_tecnico;";
					$consulta=mysql_query("SELECT id_tecnico, nombre, apellido FROM tecnicos",$link);
					$resultado=mysql_query($sql);
					if ($row = mysql_fetch_array($resultado)){

					   echo "<table border = '1' align='center'> \n"; 
					   echo "<tr><td>No. Serie</td><td>Asignado a</td><td>Fecha de instalacion</td><td>Suscriptor</td><td>Estado</td><td>Opciones</td></tr> \n"; 
					   do {
					   	if (is_null($row['fec_inst'])) {
							echo " ";			
						}
						else{
							$id_serie=$row['no_serie'];
							mysql_query("UPDATE equipos SET estado='Entregado' where no_serie='$id_serie';",$link);
						}
					      echo "<tr><td>".$row["no_serie"]."</td><td>".$row["nombre"]." ".$row["apellido"]."</td><td>".$row["fec_inst"]."</td><td>".$row["suscriptor"]."
						
					    </td><td>".$row["estado"]."</td><td>
							<img class='border' src='../img/editar_equipo.png' onclick='ocultar_mostrar(".$vuelta.")' title='Asignar a técnico'>
								<article id=".$vuelta." class='opcion'>
									<img  src='../img/cerrar.png' onclick='ocultar_mostrar(".$vuelta.")' class='cerrar' title='Cerrar'>";
								if(is_null($row['fec_inst'])){
								echo	"<form method='POST' action='asignar.php'>
										<h3>Asignar equipo</h3>
										<span>No. serie: </span>
										<input type='text'  name='serie' readonly='readonly' value=".$row["no_serie"]." placerholder=".$row["no_serie"].">
										<span>Asignar a: </span>
										<select name='tecnico'>
											<option value=' '>Ninguno</option>";
										$consulta=mysql_query("SELECT id_tecnico, nombre, apellido FROM tecnicos where fec_salida is NULL OR fec_salida='0000-00-00'",$link);
										while ($tecnicos=mysql_fetch_array($consulta)){
									
												echo "<option value=".$tecnicos['id_tecnico'].">".$tecnicos['nombre']." ".$tecnicos['apellido']."</option>";
										}
										echo  "</select>
										<input type='submit' value='Aceptar'>
									</form>";
								}
								else{
									echo "<br /><br /><br /><h4>El equipo ya ha sido entregado y no se puede reasignar</h4>";
								}
								echo "</article>
					   	</td></tr> \n"; 
					      		$vuelta=$vuelta+1;
					   } while ($row = mysql_fetch_array($resultado)); 
					   echo "</table> \n"; 
					} else { 
					echo "<h3>¡ No se ha encontrado ningún registro !</h3>"; 
					}
					mysql_close($link);
				?>
				</table>
			</div>
			<br><span class='notificacion'>*Si los registros paracen erroneos cargue la página nuevamente</span>
		</section>
		<footer>
			<p id="version">Version 1.0 Ultima actualización 00/00/00</p>
			<p class="" id="powered">Powered by César Eduardo</p>
		</footer>
	</div>
</body>
</html>