<?php 

$serie=$_POST['serie'];
$tecnico=$_POST['tecnico'];
include("../php/conexion.php");
$link=conectar();

$sql="INSERT INTO equipos (no_serie,id_tecnico) values ('$serie','$tecnico');";

//mysql_query($sql,$link);
if (mysql_query($sql,$link)) {
	header("location:hecho.php");
} 
else {
	header("location:../error/error1003x.php");
}

?>