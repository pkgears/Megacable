<?php 
session_start();

echo $_SESSION["usuario"];
echo $_SESSION["primer_nombre"];
echo $_SESSION["segundo_nombre"];


 ?>